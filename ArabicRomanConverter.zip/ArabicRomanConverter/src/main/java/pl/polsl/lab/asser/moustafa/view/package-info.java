/**
 * Handles user interface. 
 * Contains one class <code>View.java</code>.
 */
package pl.polsl.lab.asser.moustafa.view;
